package com.trox.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.trox.launcher.R;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {

    private static final int PICK_SKIN = 101;
    private static final int PICK_CAPE = 102;
    private static final String CLIENT_ID = "00000000402b5328";
    private static final String REDIRECT_URI = "https://login.live.com/oauth20_desktop.srf";

    private LinearLayout cardAccount;
    private ImageView imgPlayerHead;
    private ImageView imgLauncherLogo;
    private TextView txtUsername;
    private TextView txtAccountType;
    private Button btnPlay;
    private SharedPreferences prefs;

    private final List<String> releaseList = new ArrayList<String>();
    private final List<String> snapshotList = new ArrayList<String>();
    private final List<String> betaList = new ArrayList<String>();
    private final List<String> alphaList = new ArrayList<String>();
    private boolean isVersionsLoaded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        prefs = getSharedPreferences("TroxLauncherPrefs", Context.MODE_PRIVATE);

        cardAccount = findViewById(R.id.cardAccount);
        imgPlayerHead = findViewById(R.id.imgPlayerHead);
        imgLauncherLogo = findViewById(R.id.imgLauncherLogo);
        txtUsername = findViewById(R.id.txtUsername);
        txtAccountType = findViewById(R.id.txtAccountType);
        btnPlay = findViewById(R.id.btnPlay);

        Button btnUploadSkin = findViewById(R.id.btnUploadSkin);
        Button btnUploadCape = findViewById(R.id.btnUploadCape);
        Button btnAdd = findViewById(R.id.btnAdd);

        imgLauncherLogo.setImageBitmap(generateAccurateLogo());

        updateAccountUI();
        updatePlayButton();

        new FetchVersionsTask().execute();

        cardAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = prefs.getString("username", null);
                if (username != null && !username.isEmpty()) {
                    showLogoutDialog();
                } else {
                    startMicrosoftAuthDialog();
                }
            }
        });

        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showVersionPickerDialog();
            }
        });

        btnUploadSkin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/png");
                startActivityForResult(intent, PICK_SKIN);
            }
        });

        btnUploadCape.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.setType("image/png");
                startActivityForResult(intent, PICK_CAPE);
            }
        });

        btnPlay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = prefs.getString("username", null);
                String loader = prefs.getString("selected_loader", "Vanilla");
                String version = prefs.getString("selected_version", "1.20.4");
                String loaderVer = prefs.getString("selected_loader_version", "");

                if (username == null || username.isEmpty()) {
                    Toast.makeText(MainActivity.this, "Pehle ACCOUNT login karo!", Toast.LENGTH_SHORT).show();
                    startMicrosoftAuthDialog();
                } else {
                    String info = loader.equals("Vanilla") ? version : loader + " (" + loaderVer + ") - " + version;
                    Toast.makeText(MainActivity.this, "Launching " + info + " as " + username, Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void updatePlayButton() {
        String loader = prefs.getString("selected_loader", "Vanilla");
        String version = prefs.getString("selected_version", "1.20.4");
        String loaderVer = prefs.getString("selected_loader_version", "");

        if ("Fabric".equals(loader) && !loaderVer.isEmpty()) {
            btnPlay.setText("PLAY (Fabric " + loaderVer + ")");
        } else if (!"Vanilla".equals(loader)) {
            btnPlay.setText("PLAY (" + loader + " " + version + ")");
        } else {
            btnPlay.setText("PLAY (Vanilla " + version + ")");
        }
    }

    private void showVersionPickerDialog() {
        if (!isVersionsLoaded && releaseList.isEmpty()) {
            Toast.makeText(this, "Versions load ho rahe hain, ek second...", Toast.LENGTH_SHORT).show();
            new FetchVersionsTask().execute();
            return;
        }

        final Dialog dialog = new Dialog(this, android.R.style.Theme_DeviceDefault_Dialog);
        dialog.setTitle("Select Minecraft Version");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#1E1E1E"));
        root.setPadding(20, 20, 20, 20);

        HorizontalScrollView scrollTabs = new HorizontalScrollView(this);
        LinearLayout tabContainer = new LinearLayout(this);
        tabContainer.setOrientation(LinearLayout.HORIZONTAL);

        final Button tabRelease = createTabButton("RELEASE", true);
        final Button tabSnapshot = createTabButton("SNAPSHOTS", false);
        final Button tabBeta = createTabButton("BETA", false);
        final Button tabAlpha = createTabButton("ALPHA", false);

        tabContainer.addView(tabRelease);
        tabContainer.addView(tabSnapshot);
        tabContainer.addView(tabBeta);
        tabContainer.addView(tabAlpha);
        scrollTabs.addView(tabContainer);
        root.addView(scrollTabs);

        final ListView listView = new ListView(this);
        final ArrayList<String> currentDisplayList = new ArrayList<String>(releaseList);
        final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, currentDisplayList);
        listView.setAdapter(adapter);
        root.addView(listView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 600));

        View.OnClickListener tabListener = new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                resetTabStyles(tabRelease, tabSnapshot, tabBeta, tabAlpha);
                ((Button) v).setBackgroundColor(Color.parseColor("#D32F2F"));
                ((Button) v).setTextColor(Color.WHITE);

                currentDisplayList.clear();
                if (v == tabRelease) {
                    currentDisplayList.addAll(releaseList);
                } else if (v == tabSnapshot) {
                    currentDisplayList.addAll(snapshotList);
                } else if (v == tabBeta) {
                    currentDisplayList.addAll(betaList);
                } else if (v == tabAlpha) {
                    currentDisplayList.addAll(alphaList);
                }
                adapter.notifyDataSetChanged();
            }
        };

        tabRelease.setOnClickListener(tabListener);
        tabSnapshot.setOnClickListener(tabListener);
        tabBeta.setOnClickListener(tabListener);
        tabAlpha.setOnClickListener(tabListener);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String selectedVer = currentDisplayList.get(position);
                dialog.dismiss();
                showModLoaderDialog(selectedVer);
            }
        });

        dialog.setContentView(root, new ViewGroup.LayoutParams(700, ViewGroup.LayoutParams.WRAP_CONTENT));
        dialog.show();
    }

    private void showModLoaderDialog(final String version) {
        final String[] loaders = new String[]{"Vanilla", "Fabric", "Forge", "NeoForge", "Quilt", "OptiFine"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select Loader for " + version);
        builder.setItems(loaders, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String selectedLoader = loaders[which];
                if ("Fabric".equals(selectedLoader)) {
                    showFabricLoaderVersionDialog(version);
                } else {
                    prefs.edit()
                            .putString("selected_version", version)
                            .putString("selected_loader", selectedLoader)
                            .remove("selected_loader_version")
                            .apply();
                    updatePlayButton();
                    Toast.makeText(MainActivity.this, selectedLoader + " " + version + " Selected!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.show();
    }

    private void showFabricLoaderVersionDialog(final String mcVersion) {
        final String[] fabricLoaders = new String[]{"0.19.3 (Latest)", "0.16.9", "0.16.5", "0.15.11", "0.14.24"};

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select Fabric Loader Version");
        builder.setItems(fabricLoaders, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String fullChoice = fabricLoaders[which];
                String loaderVer = fullChoice.split(" ")[0];

                prefs.edit()
                        .putString("selected_version", mcVersion)
                        .putString("selected_loader", "Fabric")
                        .putString("selected_loader_version", loaderVer)
                        .apply();
                updatePlayButton();
                Toast.makeText(MainActivity.this, "Fabric " + loaderVer + " (" + mcVersion + ") Selected!", Toast.LENGTH_SHORT).show();
            }
        });
        builder.show();
    }

    // Exact Pixel Matrix for COGY_TROX 8x8 Head (160x160 canvas)
    private Bitmap generateAccurateLogo() {
        int w = 8, h = 8;
        int[][] pixels = {
                {0xFFD21414, 0xFFD21414, 0xFFD21414, 0xFFD21414, 0xFFD21414, 0xFFD21414, 0xFFD21414, 0xFFD21414},
                {0xFF930C0C, 0xFF930C0C, 0xFFFFFFFF, 0xFFFFFFFF, 0xFF930C0C, 0xFFFFFFFF, 0xFFFFFFFF, 0xFF930C0C},
                {0xFFD21414, 0xFFD21414, 0xFFD21414, 0xFFD21414, 0xFFD21414, 0xFFD21414, 0xFFD21414, 0xFFD21414},
                {0xFFE2A76F, 0xFFE2A76F, 0xFF141414, 0xFF141414, 0xFF141414, 0xFF141414, 0xFFE2A76F, 0xFFE2A76F},
                {0xFFE2A76F, 0xFF141414, 0xFF141414, 0xFF141414, 0xFF141414, 0xFF141414, 0xFF141414, 0xFFE2A76F},
                {0xFFE2A76F, 0xFFD21414, 0xFFD21414, 0xFFE2A76F, 0xFFE2A76F, 0xFFD21414, 0xFFD21414, 0xFFE2A76F},
                {0xFFE2A76F, 0xFFFFFFFF, 0xFFD21414, 0xFFE2A76F, 0xFFE2A76F, 0xFFD21414, 0xFFFFFFFF, 0xFFE2A76F},
                {0xFFE2A76F, 0xFFE2A76F, 0xFFE2A76F, 0xFFE2A76F, 0xFFE2A76F, 0xFFE2A76F, 0xFFE2A76F, 0xFFE2A76F}
        };

        Bitmap base = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888);
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                base.setPixel(x, y, pixels[y][x]);
            }
        }
        return Bitmap.createScaledBitmap(base, 160, 160, false);
    }

    private Button createTabButton(String text, boolean isSelected) {
        Button btn = new Button(this);
        btn.setText(text);
        btn.setTextSize(12);
        btn.setPadding(24, 10, 24, 10);
        if (isSelected) {
            btn.setBackgroundColor(Color.parseColor("#D32F2F"));
            btn.setTextColor(Color.WHITE);
        } else {
            btn.setBackgroundColor(Color.parseColor("#2E2E2E"));
            btn.setTextColor(Color.parseColor("#AAAAAA"));
        }
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.setMargins(6, 0, 6, 12);
        btn.setLayoutParams(params);
        return btn;
    }

    private void resetTabStyles(Button... buttons) {
        for (Button btn : buttons) {
            btn.setBackgroundColor(Color.parseColor("#2E2E2E"));
            btn.setTextColor(Color.parseColor("#AAAAAA"));
        }
    }

    private class FetchVersionsTask extends AsyncTask<Void, Void, Void> {
        @Override
        protected Void doInBackground(Void... voids) {
            try {
                String manifestUrl = "https://piston-meta.mojang.com/mc/game/version_manifest_v2.json";
                String jsonStr = sendGet(manifestUrl, null);
                JSONObject root = new JSONObject(jsonStr);
                JSONArray versions = root.getJSONArray("versions");

                releaseList.clear();
                snapshotList.clear();
                betaList.clear();
                alphaList.clear();

                for (int i = 0; i < versions.length(); i++) {
                    JSONObject ver = versions.getJSONObject(i);
                    String id = ver.getString("id");
                    String type = ver.getString("type");

                    if ("release".equals(type)) {
                        releaseList.add(id);
                    } else if ("snapshot".equals(type)) {
                        snapshotList.add(id);
                    } else if ("old_beta".equals(type)) {
                        betaList.add(id);
                    } else if ("old_alpha".equals(type)) {
                        alphaList.add(id);
                    }
                }
                isVersionsLoaded = true;
            } catch (Exception e) {
                releaseList.add("1.21.1");
                releaseList.add("1.21");
                releaseList.add("1.20.4");
                releaseList.add("1.20.2");
                releaseList.add("1.19.4");
                releaseList.add("1.18.2");
                releaseList.add("1.16.5");
                releaseList.add("1.12.2");
                releaseList.add("1.8.9");
            }
            return null;
        }
    }

    private void updateAccountUI() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                String username = prefs.getString("username", null);
                String headBase64 = prefs.getString("head_base64", null);

                if (username != null && !username.isEmpty()) {
                    txtUsername.setText(username);
                    txtUsername.setTextColor(Color.WHITE);
                    txtAccountType.setText("Microsoft Account");
                    txtAccountType.setVisibility(View.VISIBLE);

                    if (headBase64 != null && !headBase64.isEmpty()) {
                        byte[] decoded = Base64.decode(headBase64, Base64.DEFAULT);
                        Bitmap headBitmap = BitmapFactory.decodeByteArray(decoded, 0, decoded.length);
                        imgPlayerHead.setImageBitmap(headBitmap);
                        imgPlayerHead.setVisibility(View.VISIBLE);
                    } else {
                        new FetchHeadOnlyTask().execute(username);
                    }
                } else {
                    txtUsername.setText("ACCOUNT +");
                    txtUsername.setTextColor(Color.parseColor("#E53935"));
                    txtAccountType.setVisibility(View.GONE);
                    imgPlayerHead.setVisibility(View.GONE);
                }
            }
        });
    }

    private void showLogoutDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Account Actions");
        builder.setItems(new String[]{"Switch / Re-login Microsoft", "Logout Account"}, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                if (which == 0) {
                    startMicrosoftAuthDialog();
                } else {
                    prefs.edit().clear().apply();
                    updateAccountUI();
                    Toast.makeText(MainActivity.this, "Logged out!", Toast.LENGTH_SHORT).show();
                }
            }
        });
        builder.show();
    }

    private void startMicrosoftAuthDialog() {
        final Dialog authDialog = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);

        WebView webView = new WebView(this);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setUserAgentString("Mozilla/5.0 (Linux; Android 10; Mobile) AppleWebKit/537.36 Chrome/114.0.0.0 Mobile Safari/537.36");

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        String loginUrl = "https://login.live.com/oauth20_authorize.srf"
                + "?client_id=" + CLIENT_ID
                + "&response_type=code"
                + "&scope=service::user.auth.xboxlive.com::MBI_SSL"
                + "&redirect_uri=" + REDIRECT_URI
                + "&prompt=select_account";

        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return checkUrl(request.getUrl().toString(), authDialog);
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return checkUrl(url, authDialog);
            }

            private boolean checkUrl(String url, Dialog dialog) {
                if (url.startsWith(REDIRECT_URI)) {
                    if (url.contains("code=")) {
                        String code = url.substring(url.indexOf("code=") + 5);
                        if (code.contains("&")) {
                            code = code.substring(0, code.indexOf("&"));
                        }
                        dialog.dismiss();
                        Toast.makeText(MainActivity.this, "Logging in...", Toast.LENGTH_SHORT).show();
                        new FetchMinecraftProfileTask().execute(code);
                        return true;
                    }
                }
                return false;
            }
        });

        webView.loadUrl(loginUrl);
        authDialog.setContentView(webView, new ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        authDialog.show();
    }

    private class FetchMinecraftProfileTask extends AsyncTask<String, Void, Void> {
        private String finalName = "COGY_TROX";
        private Bitmap headBitmap = null;

        @Override
        protected Void doInBackground(String... params) {
            String code = params[0];
            try {
                String liveTokenUrl = "https://login.live.com/oauth20_token.srf";
                String liveParams = "client_id=" + CLIENT_ID
                        + "&code=" + code
                        + "&grant_type=authorization_code"
                        + "&redirect_uri=" + REDIRECT_URI
                        + "&scope=service::user.auth.xboxlive.com::MBI_SSL";

                String liveResponse = sendPost(liveTokenUrl, liveParams, "application/x-www-form-urlencoded", null);
                JSONObject liveJson = new JSONObject(liveResponse);
                String liveAccessToken = liveJson.getString("access_token");

                String xblUrl = "https://user.auth.xboxlive.com/user/authenticate";
                JSONObject xblReq = new JSONObject();
                JSONObject xblProps = new JSONObject();
                xblProps.put("AuthMethod", "RPS");
                xblProps.put("SiteName", "user.auth.xboxlive.com");
                xblProps.put("RpsTicket", "d=" + liveAccessToken);
                xblReq.put("Properties", xblProps);
                xblReq.put("RelyingParty", "http://auth.xboxlive.com");
                xblReq.put("TokenType", "JWT");

                String xblResponse = sendPost(xblUrl, xblReq.toString(), "application/json", null);
                JSONObject xblJson = new JSONObject(xblResponse);

                JSONArray xui = xblJson.getJSONObject("DisplayClaims").getJSONArray("xui");
                if (xui.length() > 0 && xui.getJSONObject(0).has("gtg")) {
                    finalName = xui.getJSONObject(0).getString("gtg");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            headBitmap = fetchHeadDirect(finalName);
            return null;
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            saveAndApplyUser(finalName, headBitmap);
        }
    }

    private class FetchHeadOnlyTask extends AsyncTask<String, Void, Bitmap> {
        private String name;

        @Override
        protected Bitmap doInBackground(String... params) {
            name = params[0];
            return fetchHeadDirect(name);
        }

        @Override
        protected void onPostExecute(Bitmap bitmap) {
            if (bitmap != null) {
                saveAndApplyUser(name, bitmap);
            }
        }
    }

    private Bitmap fetchHeadDirect(String name) {
        Bitmap bmp = downloadBitmap("https://mc-heads.net/avatar/" + name + "/64.png");
        if (bmp == null) {
            bmp = downloadBitmap("https://minotar.net/helm/" + name + "/64.png");
        }
        return bmp;
    }

    private void saveAndApplyUser(String name, Bitmap headBmp) {
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("username", name);
        editor.putString("account_type", "Microsoft Account");

        if (headBmp != null) {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            headBmp.compress(Bitmap.CompressFormat.PNG, 100, baos);
            String headBase64 = Base64.encodeToString(baos.toByteArray(), Base64.DEFAULT);
            editor.putString("head_base64", headBase64);
        }

        editor.apply();
        updateAccountUI();
        Toast.makeText(MainActivity.this, "Welcome " + name + "!", Toast.LENGTH_SHORT).show();
    }

    private Bitmap downloadBitmap(String urlStr) {
        try {
            URL url = new URL(urlStr);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoInput(true);
            conn.setConnectTimeout(6000);
            conn.setReadTimeout(6000);
            conn.connect();
            return BitmapFactory.decodeStream(conn.getInputStream());
        } catch (Exception e) {
            return null;
        }
    }

    private String sendPost(String urlStr, String payload, String contentType, String authHeader) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", contentType);
        conn.setRequestProperty("Accept", "application/json");
        if (authHeader != null) conn.setRequestProperty("Authorization", authHeader);
        conn.setDoOutput(true);

        try (OutputStream os = conn.getOutputStream()) {
            os.write(payload.getBytes(StandardCharsets.UTF_8));
        }

        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        return sb.toString();
    }

    private String sendGet(String urlStr, String bearerToken) throws Exception {
        URL url = new URL(urlStr);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");
        if (bearerToken != null) {
            conn.setRequestProperty("Authorization", "Bearer " + bearerToken);
        }
        conn.setRequestProperty("Accept", "application/json");

        BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        return sb.toString();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == RESULT_OK && data != null && data.getData() != null) {
            if (requestCode == PICK_SKIN) {
                Toast.makeText(this, "Skin uploaded!", Toast.LENGTH_SHORT).show();
            } else if (requestCode == PICK_CAPE) {
                Toast.makeText(this, "Cape uploaded!", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
